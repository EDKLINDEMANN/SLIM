# Hyperloop_SLIM_Design
Single sided linear induction motor Matlab simulation
