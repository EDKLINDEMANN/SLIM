%% Flow chart part D

% calculate synchronous velocity (V sub s)

V_s = 2*f*tau;
