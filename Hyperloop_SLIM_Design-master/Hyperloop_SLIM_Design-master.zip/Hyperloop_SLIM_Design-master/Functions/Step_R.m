%% Step R

N_p = 1;

