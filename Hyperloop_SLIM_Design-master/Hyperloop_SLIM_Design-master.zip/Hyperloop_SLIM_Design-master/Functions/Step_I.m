%% flowchart step I

% estimate rated RMS stator current, I-prime sub 1

Iprime_1 = (Fprime_s * V_r)/(m*V_1*eacosp); 