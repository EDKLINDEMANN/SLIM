%% Flowchart step g

N_1 = N_c * p * q_1 %number of turns per phase
