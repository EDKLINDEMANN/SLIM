%% Step t
%recalculating all these variable to recalculate G (goodness factor)
g_e=_c*g_0;                    %Effective air gap
k_c=(lambda)/(lambda-gamma*g_0) %carter's coefficient
W_se= W_s+ g_0;                 %Equivalent stator width