%% Step E
tau=V_s/2*f;            %calculate the pole pitch
lambda=tau/m*q_1        %calculate slot pitch
L_s=p*tau               %length of one stator unit 
