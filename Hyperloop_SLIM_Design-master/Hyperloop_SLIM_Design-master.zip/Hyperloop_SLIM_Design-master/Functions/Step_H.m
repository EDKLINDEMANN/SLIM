%% flowchart step h

eacosp = 0.69420; %eta*cos(phi) = between 0 and 1

