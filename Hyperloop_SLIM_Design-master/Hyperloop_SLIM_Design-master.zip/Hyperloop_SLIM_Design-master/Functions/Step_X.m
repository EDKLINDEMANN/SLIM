%% Step_X %%

h_y = (flux_p)/(2*B_ymax*W_s)
