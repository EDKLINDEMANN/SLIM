%% Step C 
Fprime_s=input('Target electromagnetic thrust, Fs   ');
V_r=input('Rated rotor velocity, Vr   ');
