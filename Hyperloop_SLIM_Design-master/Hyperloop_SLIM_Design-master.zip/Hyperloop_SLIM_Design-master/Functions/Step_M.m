%% Step M
R_1 = (lambda_w*((l_w)/(A_wt)));

lambda_s = ((h_s)*(1+3*k_p))/12*W_s
lambda_e = 0.3*((3*k_p)-1)
lambda_d = 5*((G_e)/(W_s))/5 + 4*((G_0)/(W_s))
X_1 = (2*mu_0*pi*f*((lambda_s*(1+(3/p))+lambda_d)*(W_s/q_1)+lambda_e*l_ce)*(N_1)^2)/p

X_m = (24*mu_0*pi*f*w_se*k_w*((n_1)^2)*tau)/(pi^2)*p*g
R_2 = (x_m)/(G)
