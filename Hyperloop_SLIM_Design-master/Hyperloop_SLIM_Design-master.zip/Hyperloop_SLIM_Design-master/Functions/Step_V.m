%% Finding a minimum value for tooth width to produce required flux density
W_tmin=((2*sqrt(2))*m*k_w*N_i*I_m*mu_0*lambda)/(pi*g_e*p*B_tmax);  %minimum tooth density
%if minimum is greater than the actual width, change number of parallel wires and their arrangement inside  slot