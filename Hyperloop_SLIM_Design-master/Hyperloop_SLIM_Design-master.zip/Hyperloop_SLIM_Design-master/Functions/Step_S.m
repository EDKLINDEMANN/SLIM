%% Step s
%finding neew values for slot width,W_s, and tooth width,W-t,
w_s=D_w*N_p+2*t_I;
w_t=lambda-w_s;