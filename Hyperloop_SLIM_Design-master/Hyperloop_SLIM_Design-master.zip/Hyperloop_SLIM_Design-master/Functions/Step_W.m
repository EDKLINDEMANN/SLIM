%% Step_W %%

J_1 = (I_l)/(A_w)
