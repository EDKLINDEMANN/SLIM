%% Flow chart step f

% assume w_s = w_t = lambda/2 [lambda: slot pitch] 

w_s = lambda / 2; %slot width
w_t = w_s; %tooth width