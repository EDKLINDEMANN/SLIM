%% Step F sub 1

N_c = 1; %number of turns per slot