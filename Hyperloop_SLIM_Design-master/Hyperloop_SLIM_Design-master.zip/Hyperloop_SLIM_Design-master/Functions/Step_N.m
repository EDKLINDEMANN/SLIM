%% Step N
Z = R_1 + (j*X_1) + (j*((R_2/S)*X_m))/((R_2/S)+ J*X_m)

cos_phi = F_s*2*pi*f_1 + 3*R_1*(I_1)^2
I_1 = (V_1)/abs(Z)
I_m = (I_1 * R_2)/sqrt((R_2)^2 + (S*X_m)^2)